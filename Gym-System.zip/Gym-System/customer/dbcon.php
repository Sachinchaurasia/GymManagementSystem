

<?php
$conn = mysqli_connect("localhost","Sachin1","Sachin@123","gymnsb");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
// $servername="localhost";
// $username="Sachin1";
// $password="Sachin@123";
// $dbname="gymnsb";
// $conn=new mysqli($servername,$username,$password,$dbname);
// if($conn->connect_error){
//   die("connection failed");
// }
?>

